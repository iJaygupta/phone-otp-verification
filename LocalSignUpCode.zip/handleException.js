const SignupDao = require("./signUpDao");
let moment = require('moment');


const handleExceptions = async (exception, event) => {
    var msg;
    if (exception.origin === 'cognito') {
        msg = await handleSignUpPhoneVerifyExceptions(exception);
        if (exception.statusCode === 400) {
            await putErrorToDb(event.payload.username, JSON.stringify(exception), getDateTime("YYYY-MM-DDTHH:mm:ss.SSS"), 'SignUp')
        }
    }
    else if (exception.origin === 'db') {
        msg = await handleSignUpPhoneVerifyDBExceptions(exception);
        if (exception.statusCode === 400) {
            await putErrorToDb(event.payload.username, JSON.stringify(exception), getDateTime("YYYY-MM-DDTHH:mm:ss.SSS"), 'SignUp')
        }
    }
    else {
        msg = 'Something has gone wrong Please try again.';
        exception.statusCode = 400;
        console.log("+++++++++++++++============================>", JSON.stringify(exception));
    }
    throw new Error(createResponse(exception.statusCode, msg, 'string'));
}


const handleSignUpPhoneVerifyExceptions = (error) => {

    let msg;
    switch (error.code) {
        case 'AuthorizationError':
            msg = 'Something has gone wrong, Code Delivery has been Failed. Please try again.';
            break;

        case 'InternalError':
            msg = 'Internal Server Error';
            break;

        case 'TooManyRequestsException':
            msg = 'Internal Server Error';
            break;

        case 'NotFound':
            msg = 'Internal Server Error';
            break;

        case 'CodeDeliveryFailureException':
            msg = 'Something has gone wrong, Code Delivery has been Failed. Please try again.';
            break;

        case 'ParameterValueInvalid':
            msg = 'Something has gone wrong, Code Delivery has been Failed. Please try again.';
            break;

        case 'KMSNotFound':
            msg = 'Something has gone wrong, Code Delivery has been Failed. Please try again.';
            break;
        case 'InvalidParameterException':
            msg = 'Something has gone wrong, Code Delivery has been Failed. Please try again.';
            break;
        default:
            msg = "Error Occurred while processing request";
            break;

    }
    return msg;

}


const handleSignUpPhoneVerifyDBExceptions = (error) => {
    let msg;
    switch (error.code) {
        case 'ConditionalCheckFailedException':
        case 'InternalServerError':
            msg = 'Internal server error.';
            break;

        case 'ItemCollectionSizeLimitExceededException':
        case 'ProvisionedThroughputExceededException':
        case 'TransactionConflictException':
            msg = 'Something went wrong. Please try again.';
            break;
        case 'ResourceNotFoundException':
        case 'RequestLimitExceeded':
            msg = 'Something went wrong.Please contact server administrator.';
            break;
        case 'ValidationException':
            msg = 'Validation Failed Please Try With Correct Attributes.';
            break;
        default:
            msg = "Error Occurred in DB Operations while Processing request";
            break;
    }
    return msg;
}


const createResponse = (statusCode, body, type) => {
    const resp = {
        statusCode,
        body: body
    }
    if (type && type === 'string') {
        return JSON.stringify(resp);
    } else {
        return resp;
    }
}

const getDateTime = (dateTimeFormat) => {
    return moment(new Date()).format(dateTimeFormat);
}

const putErrorToDb = async (username, error, dateTime, type) => {
    try {
        await SignupDao.putDataIntoDb(SignupDao.prepareErrorParams(username, error, dateTime, type));
    } catch (err) {
        console.log(err);
    }
}



module.exports = { handleExceptions }
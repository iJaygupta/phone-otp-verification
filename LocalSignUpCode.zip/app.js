const AWS = require('aws-sdk');
AWS.config.update({ region: 'ap-southeast-1' });
const SignupDao = require("./signUpDao");
const { handleExceptions } = require("./handleException")
let moment = require('moment');
const COGNITO_PHONE_CODE_ALLOWED = 3;
const COGNITO_PHONE_CODE_VERIFY_ALLOWED = 3;
const PHONE_CODE_VALIDITY = {
    timeLimit: 2,
    timeType: 'minutes'
}
const SNS = new AWS.SNS();
let {
    getParamValue,
    getParametersMap
} = require('./paramLoader');
AWS.config.update({
    region: 'ap-southeast-1'
});
const cisp = new AWS.CognitoIdentityServiceProvider({
    apiVersion: '2016-04-18',
});
let loadEnvValues;

const usersErrorTableSchema = {
    tableName: "ph_users_error",
    partitionKeyName: "id",
    sortKeyName: "dateTime"
};

exports.lambdaHandler = async (event) => {
    if (!(await loadSSMFunction())) {
        const body = 'Error loading configuration.'
        throw new Error(createResponse(400, body, 'string'));
    };

    try {
        let result;
        switch (event.action) {
            case 'sendPhoneCode':
                result = await sendPhoneCodeFunction(event);
                break;
            case 'verifyPhone':
                result = await verifyPhoneFunction(event);
                break;
            case 'changePhone':
                result = await changePhoneFunction(event);
                break;

        }
        return result;
    } catch (error) {
        return error;
    }

}

const errorObj = {
    code: "ParameterValueInvalid",
    statusCode: 400,
    origin: "cognito"

}

/*
Loads userpool and client id from parameter store.
*/
let loadSSMFunction = async () => {
    if (loadEnvValues === undefined) {
        const keyArray = '{"Keys":["ph_customer_clientId","ph_customer_userpoolId"]}';

        try {
            loadEnvValues = await getParametersMap(keyArray)
            // clientId = loadEnvValues.get("ph_customer_clientId");
            //userPoolId = loadEnvValues.get("ph_customer_userpoolId")
            return true;
        } catch (error) {
            return false
        }
    }
    return true;
}

/*
creates response object
*/
const createResponse = (statusCode, body, type) => {
    const resp = {
        statusCode,
        body: body
    }
    if (type && type === 'string') {
        return JSON.stringify(resp);
    } else {
        return resp;
    }
}


const sendPhoneCodeFunction = async (event) => {

    try {
        let userDetails = await SignupDao.getDataFromDb(SignupDao.prepareParamToGetUser(event.payload.username));
        userDetails = userDetails.Item || userDetails || {}
        if (!Object.keys(userDetails).length || !userDetails.emailVerified) {
            const body = {
                message: "User Not Allowed to Send Phone Code"
            }
            return createResponse(200, body)
        }
        if (userDetails.phoneVerified) {
            const body = {
                message: "Phone Already Verified"
            }
            return createResponse(200, body);
        }

        let isUserAllowed = await phoneCodeSendAllowedFunction(userDetails)
        if (!isUserAllowed) {
            const body = {
                message: "Too Many UnSuccessful Attempts Please Try Again Later"
            }
            return createResponse(200, body)

        }
        let otp = generateRandomCode();
        let phoneCodeSendDateTime = await sendSMS(event.payload.phoneNumber, otp);
        await SignupDao.putDataIntoDb(SignupDao.prepareParamToPutUserOTPDetail(userDetails.id, phoneCodeSendDateTime, otp, "signup_phone_verify"));
        await SignupDao.updateDataIntoDb(SignupDao.prepareParamToUpdateUserOTP(userDetails, phoneCodeSendDateTime));
        const body = {
            verify: "verifyPhone"
        }
        return createResponse(200, body);
    } catch (err) {
        handleExceptions(err, event);
    }
}


let calculateTimeDiff = (date) => {
    var now = moment(new Date(), loadEnvValues.get("ph_dateTimeFormat")); //todays date
    var end = moment(date, loadEnvValues.get("ph_dateTimeFormat")); // another date
    var duration = moment.duration(now.diff(end));
    var days = duration.asDays();
    return duration.asMinutes();
}

const phoneCodeSendAllowedFunction = async (userDetails) => {
    const { phoneVerifyCodeSentCount, lastPhoneVerifyCodeSentDateTime, totalPhoneVerifyCodeSentCount } = userDetails;
    if (phoneVerifyCodeSentCount && lastPhoneVerifyCodeSentDateTime && totalPhoneVerifyCodeSentCount) {
        if (phoneVerifyCodeSentCount >= COGNITO_PHONE_CODE_ALLOWED) {
            let timeDiff = calculateTimeDiff(lastPhoneVerifyCodeSentDateTime);
            // calculating time gap between last phone code requested time and current time
            if (timeDiff > PHONE_CODE_VALIDITY.timeLimit) { // check if the time gap is more than blocking time   
                return true;
            } else {
                return false; // user not allowed and still blocked
            }
        } else {
            return true;
        }
    } else {
        return true;
    }

}





const sendSMS = async (phoneNumber, otp) => {
    let params = generateParamsForMessage(phoneNumber, otp);
    return new Promise((resolve, reject) => {
        SNS.publish(params, (err, data) => {
            if (err) {
                // console.error("SNS Error :", err);
                err.origin = "cognito"
                reject(err);
            } else {
                var dateTime = new Date();
                dateTime = moment(dateTime).format("YYYY-MM-DDTHH:mm:ss.SSS")
                resolve(dateTime);
            }
        })

    })
}


const generateParamsForMessage = (phone, otp) => {
    return {
        Message: `Welcome to Credit Culture!! Your Verification code  is ${otp}`,
        MessageStructure: "string",
        PhoneNumber: phone
    }
}

const generateRandomCode = () => {
    return Math.floor(Math.random() * 1000000)
}


const verifyPhoneFunction = async (event) => {

    try {

        let userDetails = await SignupDao.getDataFromDb(SignupDao.prepareParamToGetUser(event.payload.username));
        userDetails = userDetails.Item || userDetails || {}
        //todo- fetch phone and user info from idToken.
        if (!Object.keys(userDetails).length) {
            const body = {
                message: "User Not Allowed to Verify Phone Code"
            }
            return createResponse(200, body)
        }
        if (userDetails.phoneVerified) {
            const body = {
                message: "Phone Already Verified"
            }
            return createResponse(200, body);
        }

        let isUserAllowed = await phoneCodeVerifyAllowedFunction(userDetails);
        let phoneCodeVerifyDateTime = moment(new Date()).format("YYYY-MM-DDTHH:mm:ss.SSS")
        if (!isUserAllowed) {
            const body = {
                message: "Too Many UnSuccessful Code Verify Attempts Please Try Again Later"
            }
            return createResponse(200, body)

        }
        let userOTP = await SignupDao.query(SignupDao.prepareParamsToGetOTP(event.payload.username));
        userOTP = userOTP.Items
        if (userOTP.length <= 0) {

            await SignupDao.updateDataIntoDb(SignupDao.prepareParamToUpdateUserOTPVerify(userDetails, phoneCodeVerifyDateTime));
            const body = {
                message: "You Provided Expired Code"
            }
            return createResponse(200, body)
        }
        userOTP = userOTP[userOTP.length - 1] || ""
        if (userOTP.code === event.payload.code) {
            await updatePhoneInCognito("verifyPhone", event);
            await SignupDao.updateDataIntoDb(SignupDao.prepareParamToUpdateVerifyPhone(event.payload.username));
            const body = {
                verify: "login"
            }
            return createResponse(200, body);

        } else {

            await SignupDao.updateDataIntoDb(SignupDao.prepareParamToUpdateUserOTPVerify(userDetails, phoneCodeVerifyDateTime));
            const body = {
                message: "You Provided Wrong Code Please Try Again..."
            }
            return createResponse(200, body)
        }
    } catch (err) {
        await handleExceptions(err, event);
    }
}

const phoneCodeVerifyAllowedFunction = async (userDetails) => {
    const { phoneCodeVerifyInvalidAttemptCount, lastPhoneCodeVerifyInvalidAttemptDateTime, totalPhoneCodeVerifyInvalidAttemptCount } = userDetails;
    if (phoneCodeVerifyInvalidAttemptCount && lastPhoneCodeVerifyInvalidAttemptDateTime && totalPhoneCodeVerifyInvalidAttemptCount) {
        if (phoneCodeVerifyInvalidAttemptCount >= COGNITO_PHONE_CODE_VERIFY_ALLOWED) {
            let timeDiff = calculateTimeDiff(lastPhoneCodeVerifyInvalidAttemptDateTime);// calculating time gap between last phone code requested time and current time
            if (timeDiff > PHONE_CODE_VALIDITY.timeLimit) { // check if the time gap is more than blocking time   
                await SignupDao.updateDataIntoDb(SignupDao.prepareParamToUnblockUserPhoneVerify(userDetails.id));
                return true;
            } else {
                return false; // user not allowed and still blocked
            }
        } else {
            return true;
        }

    } else {
        return true;
    }
}

const updatePhoneInCognito = async (phoneAction, event) => {
    let params = createPhoneUpdateParams(phoneAction, event);
    return new Promise((resolve, reject) => {
        cisp.adminUpdateUserAttributes(params, function (err, data) {
            if (err) {
                // console.error("Error While Updating Phone in Cognito :", err);
                err.origin = "cognito";
                reject(err);
            } else {
                resolve(data);
            }
        });
    })
}

const createPhoneUpdateParams = (phoneAction, event) => {
    let params;
    if (phoneAction === "verifyPhone") {
        params = {
            UserAttributes: [
                {
                    Name: 'phone_number_verified',
                    Value: 'true'
                },

            ],
            UserPoolId: loadEnvValues.get("ph_customer_userpoolId"),
            Username: event.payload.username
        };
    } else if (phoneAction === "changePhone") {
        params = {
            UserAttributes: [
                {
                    Name: "phone_number",
                    Value: event.payload.phoneNumber
                }
            ],
            UserPoolId: loadEnvValues.get("ph_customer_userpoolId"),
            Username: event.payload.username
        }
    }
    return params;
}


const changePhoneFunction = async (event) => {
    try {
        let userDetails = await SignupDao.getDataFromDb(SignupDao.prepareParamToGetUser(event.payload.username));
        userDetails = userDetails.Item || userDetails || {}
        if (!Object.keys(userDetails).length) {
            const body = {
                message: "User Not Allowed to Change Phone"
            }
            return createResponse(200, body)
        }

        await updatePhoneInCognito("changePhone", event);
        await SignupDao.updateDataIntoDb(SignupDao.prepareParamToUpdateChangePhone(event.payload.username, event.payload.phoneNumber));
        const body = {
            verify: "login",
            message: "User Phone Updated Successfully!!"
        }
        return createResponse(200, body);

    } catch (err) {
        await handleExceptions(err, event);
    }
}

// let json = {
//     "action": "sendPhoneCode",
//     "payload": {
//         "username": "dikshit.kathuria@creditculture.sg",
//         "password": "jay@@123",
//         "phoneNumber": "+919999991234",
//         "code": 792944
//     }
// }


// exports.lambdaHandler(json).then((data) => {
//     console.log(data);
// })